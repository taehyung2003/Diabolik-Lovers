HTML Homepage, HTML Character Page, and About Page

Produce Web page layouts and designs in accordance with usability standards and basic graphic design concepts and principles.

Apply usability and accessibility standards in Web site structure and organization.

Use semantic Hypertext Markup Language (HTML5) to structure Web documents that validate with current W3C standards

Use Cascading Style Sheets (CSS3) to style Web documents.